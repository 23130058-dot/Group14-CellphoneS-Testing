import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-item, .product-card"
String pMinK = "4000"
String pMaxK = "7000"
Thread.sleep(5000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var storedVars = { 'cssCard': cssCard,'pMinK': pMinK,'pMaxK': pMaxK }; " + "document.querySelectorAll('" + cssCard + "').length")
String resSetPrice = selenium.getEval(" var cssCard = \"" + cssCard + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var storedVars = { 'cssCard': cssCard,'pMinK': pMinK,'pMaxK': pMaxK,'n0': n0 }; " + "(function(minK, maxK){ var btns = Array.prototype.filter.call(document.querySelectorAll('button, a, div, span'), function(e){ return /xem theo gi�|kho�ng gi�|m�c gi�/i.test(e.textContent.trim()) && (e.offsetWidth > 0 || e.offsetHeight > 0); }); if(btns.length > 0){ (btns[0].closest('button, a') || btns[0]).click(); } var inputs = Array.prototype.filter.call(document.querySelectorAll('input'), function(e){ return (e.offsetWidth > 0 || e.offsetHeight > 0) && !/search|t�m/i.test(e.placeholder || ''); }); if(inputs.length >= 2){ inputs[0].focus(); inputs[0].value = minK; inputs[0].dispatchEvent(new Event('input', {bubbles:true})); inputs[0].dispatchEvent(new Event('change', {bubbles:true})); inputs[1].focus(); inputs[1].value = maxK; inputs[1].dispatchEvent(new Event('input', {bubbles:true})); inputs[1].dispatchEvent(new Event('change', {bubbles:true})); } var resBtns = Array.prototype.filter.call(document.querySelectorAll('button, a, div, span'), function(e){ return /xem k�t qu�|�p d�ng/i.test(e.textContent.trim()) && (e.offsetWidth > 0 || e.offsetHeight > 0); }); if(resBtns.length > 0){ (resBtns[0].closest('button, a') || resBtns[0]).click(); } return 'done'; })('" + pMinK + "', '" + pMaxK + "')")
Thread.sleep(4000);
String n1 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var resSetPrice = \"" + resSetPrice + "\";var storedVars = { 'cssCard': cssCard,'pMinK': pMinK,'pMaxK': pMaxK,'n0': n0,'resSetPrice': resSetPrice }; " + "document.querySelectorAll('" + cssCard + "').length")
println("Sau loc gia n1=" + n1 + " resSetPrice=" + resSetPrice)
softAssertion.assertEquals("true", selenium.getEval(n1 + " > 0"))
