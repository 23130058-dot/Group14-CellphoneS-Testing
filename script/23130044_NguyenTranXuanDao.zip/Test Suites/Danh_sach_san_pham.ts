<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Danh_sach_san_pham</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>a685edb1-e5e7-4214-957a-6d2b64bb85a5</testSuiteGuid>
   <testCaseLink>
      <guid>2a327a7e-c265-40c8-878d-24784b843d23</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_00_Kiem_tra_moi_truong</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f402fbe8-d7a3-4f1a-acda-0747c48bfe31</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_00b_Kham_pha_bo_loc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ee2b7df2-5e7f-4589-8c2a-800e4b834ecc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_01_Hien_thi_the_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ea3b426c-bc41-4a0b-8613-f93ad7d3352c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_02_GUI_bo_cuc_the_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>244d273c-9ecc-4a98-8a2f-f007fe859482</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_03_Xem_them_tai_them_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>d1c0d4e8-dcea-422d-84c0-a14ce30cadce</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_04_Loc_don_theo_hang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ca828614-d742-432b-b877-6ee5835c0cf1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_05_Loc_don_theo_khoang_gia</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>70757a34-75a3-4e03-90ff-36319d3954f3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_06_Loc_don_theo_RAM</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a2b4ea3c-0956-4807-8054-4b0dadd47c9b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_07_Loc_don_theo_bo_nho</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>3a31dd43-b5ec-42d1-8e46-241c5f0e7344</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_08_Loc_don_theo_man_hinh</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c0cec1d6-470a-4f9d-a37c-c88ca955bb5b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_09_Loc_don_theo_trang_thai_con_hang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>26644e99-2b3b-4d1b-b143-c9f94a5b38ad</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_10_Loc_ket_hop_hang_gia</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>08fdb72e-e7b8-46fd-b906-c3ca509a75b4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_11_Bo_chon_bo_loc_ve_ban_dau</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1eff0308-27c7-40ce-a13e-d421caaa964a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_12_Loc_khong_co_ket_qua</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>60f4bb5f-5ced-4883-b14a-956192fab22a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_13_Sap_xep_gia_thap_den_cao</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>9c150466-6bfd-482b-b7ca-2dc00565ab3d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_14_Sap_xep_gia_cao_den_thap</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>26faf377-f8b6-4a11-a3a1-a96de4cd389b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_15_Sap_xep_pho_bien_ban_chay</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>db4f7c88-54ec-4495-b5e7-ef024eb8f825</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_16_Sap_xep_khuyen_mai_HOT</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>680a5134-24a4-48a1-bdfc-9262e8040596</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Danh_sach_san_pham/DSSP_17_Giu_bo_loc_khi_doi_cach_sap_xep</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    