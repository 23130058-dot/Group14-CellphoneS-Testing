<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Khuyen_Mai_CellphoneS_100Percent</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>eaf6301f-d1fc-41e8-89cd-8487c891d09e</testSuiteGuid>
   <testCaseLink>
      <guid>f996987a-9ea1-4e30-adc0-baeabcc0db79</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC01_View_Promo_Page</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>d911e2f6-4785-4f79-b809-5e32c20f0933</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC02_Filter_Apple</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f05dd06d-ecc4-46d3-bb2f-cbe0796c9c2a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC03_Filter_Samsung</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>2c29f2f7-97f1-47db-9035-526b7e42ec9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC04_Filter_Phone</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>fcf4b361-107c-429a-b34f-11df39f56e3d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC05_Filter_Laptop</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>79b1b64c-2dfd-4dfb-abbe-6d4bc056544b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC06_Filter_Accessories</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>3f8a065e-ba9c-46da-9166-ba188d203ece</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC07_View_Flash_Sale</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>68e2b7d5-b285-477c-8417-135c765ef24a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC08_Sort_Price_Asc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>efe01a87-90bf-4d8e-8e7e-404181e15991</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC09_Sort_Price_Desc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e0f95474-d8dc-4c7b-b951-3a78c4f1a26c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC10_Sort_Discount_Percent</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ce38c2c9-e1d6-4570-8b4b-e7ab39a20d62</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC11_Click_Promo_Product</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>fd8dc310-4a1f-47fb-9c9b-6e1d2d264075</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC12_Check_Student_Promo</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>b072d8fe-eda9-487a-b424-6c940a13043e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC13_Pagination_More</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8b639ed5-89d0-4540-a7e9-a042e92728ed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC14_Search_Promo_Item</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f995b99e-8b43-4314-8190-75ef294f79f1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Khuyen_Mai_CellphoneS_100Percent/TC15_Bank_Payment_Offers</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    