<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Quan_Ly_Don_Hang_100Percent</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4f307b9b-9575-41f9-b1f6-81376aaab8ea</testSuiteGuid>
   <testCaseLink>
      <guid>fea17220-4a3c-4e64-9730-93fb1c27e28e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC01_Open_Track_Order</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8cdd3e67-f29f-4695-8e74-593196fbe9a4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC02_Track_Valid_Phone</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>828f66b1-1fad-4580-8ad2-fb072e195163</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC03_Track_Invalid_Phone</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e2d0324b-c70c-4aea-85db-0439f62bb7ea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC04_Track_Empty_Phone</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>09ee6f23-654c-4baa-9046-be65126bdc62</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC05_Login_Smember</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>30d41baa-f3c1-49a6-9a81-d1af6c15b33b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC06_View_Order_History</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>425175c9-8c43-4174-bd56-7e305e77d58c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC07_Filter_Processing_Orders</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ffff46a6-01b0-4566-9a8d-fca470c00765</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC08_Filter_Delivered_Orders</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e44909a2-ce1f-45e8-a520-55474077e60b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC09_Filter_Cancelled_Orders</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>50b2265c-6172-4d74-9ff1-b61184ae16dc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC10_Order_Details</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a6ac8955-0ca2-4bab-8906-4e64d6855e57</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC11_Search_Order_Code</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7724d0ef-fa5d-409e-8ca1-40ba22a98f82</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC12_Search_Invalid_Code</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>58576f00-fb7e-488e-af7c-1569579c0fc1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC13_Check_Warranty_Smember</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a3f83d35-589b-436f-816d-a6482dd20260</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC14_Back_To_Order_List</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dc019938-846d-48a9-823f-7535408b3a9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Suite_Quan_Ly_Don_Hang_100Percent/TC15_Logout_Smember</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    