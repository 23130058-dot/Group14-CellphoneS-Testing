import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
Thread.sleep(6000);
String lab = selenium.getEval("  " + "(function(){var L=['H�ng s�n xu�t', 'Xem theo gi�', 'Xem k�t qu�', 'S�n h�ng', 'Dung l��ng RAM', 'B� nh� trong', 'K�ch th��c m�n h�nh', 'Gi� Th�p - Cao', 'Gi� Cao - Th�p', 'Ph� bi�n', 'Khuy�n m�i HOT'],out=[];L.forEach(function(t){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));var n=0, total=0;els.forEach(function(e){var txt=(e.innerText||e.textContent||'').trim();if(txt===t||txt.includes(t)){total++;if(e.offsetWidth||e.offsetHeight||e.getClientRects().length)n++}});out.push(t+': '+total+' tong, '+n+' hien thi')});return out.join(' ; ')})()")
println("NHAN BO LOC: " + lab)
String bar = selenium.getEval(" var lab = \"" + lab + "\";var storedVars = { 'lab': lab }; " + "(function(){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var txt=(e.innerText||e.textContent||'').trim();if(txt==='H�ng s�n xu�t'&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){var p=e.parentNode||e;return (p.innerText||p.textContent||'').replace(/\\s+/g,' ').slice(0,500)}}return 'khong thay'})()")
println("THANH BO LOC: " + bar)
