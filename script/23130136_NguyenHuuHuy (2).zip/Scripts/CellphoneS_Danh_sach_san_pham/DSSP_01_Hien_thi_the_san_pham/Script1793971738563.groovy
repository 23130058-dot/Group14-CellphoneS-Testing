import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-info, .product-item"
String cssPrice = ".product__price--show, .product-price, .price"
String brand = "samsung"
String pMinK = "4000"
String pMaxK = "7000"
String pMin = "4000000"
String pMax = "7000000"
Thread.sleep(6000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("So the san pham hien thi ban dau n0=" + n0)
String kq1 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0 }; " + "(Number(storedVars['n0'] || '" + n0 + "') > 0) ? 'PASS' : 'FAIL: Trang hien thi the san pham'")
println("KIEM TRA Trang hien thi the san pham: " + kq1)
String nName = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1 }; " + "window.document.querySelectorAll('" + cssCard + " h3, " + cssCard + " .product__name').length")
String nImg = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1,'nName': nName }; " + "window.document.querySelectorAll('" + cssCard + " img').length")
String nPrice = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1,'nName': nName,'nImg': nImg }; " + "window.document.querySelectorAll('" + cssPrice + "').length")
String kq2 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1,'nName': nName,'nImg': nImg,'nPrice': nPrice }; " + "(Number(storedVars['nName'] || '" + nName + "') > 0) ? 'PASS' : 'FAIL: The co ten'")
println("KIEM TRA The co ten: " + kq2)
String kq3 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq2': kq2 }; " + "(Number(storedVars['nImg'] || '" + nImg + "') > 0) ? 'PASS' : 'FAIL: The co anh'")
println("KIEM TRA The co anh: " + kq3)
String kq4 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'kq1': kq1,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq2': kq2,'kq3': kq3 }; " + "(Number(storedVars['nPrice'] || '" + nPrice + "') > 0) ? 'PASS' : 'FAIL: The co gia'")
println("KIEM TRA The co gia: " + kq4)
