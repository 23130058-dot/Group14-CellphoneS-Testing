import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-info, .product-item"
String cssPrice = ".product__price--show, .product-price, .price"
String brand = "samsung"
String pMinK = "4000"
String pMaxK = "7000"
String pMin = "4000000"
String pMax = "7000000"
Thread.sleep(6000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("So the san pham hien thi ban dau n0=" + n0)
String nName = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0 }; " + "window.document.querySelectorAll('" + cssCard + " h3, " + cssCard + " .product__name').length")
String nImg = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName }; " + "window.document.querySelectorAll('" + cssCard + " img').length")
String nPrice = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg }; " + "window.document.querySelectorAll('" + cssPrice + "').length")
String kq5 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg,'nPrice': nPrice }; " + "(Number(storedVars['nName'] || '" + nName + "') > 0) ? 'PASS' : 'FAIL: Co ten san pham'")
println("KIEM TRA Co ten san pham: " + kq5)
String kq6 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq5': kq5 }; " + "(Number(storedVars['nImg'] || '" + nImg + "') > 0) ? 'PASS' : 'FAIL: Co anh san pham'")
println("KIEM TRA Co anh san pham: " + kq6)
String kq7 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq5': kq5,'kq6': kq6 }; " + "(Number(storedVars['nPrice'] || '" + nPrice + "') > 0) ? 'PASS' : 'FAIL: Co gia'")
println("KIEM TRA Co gia: " + kq7)
String kq8 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq5': kq5,'kq6': kq6,'kq7': kq7 }; " + "(function(){var e=Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(el){return !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length)});if(!e||e.length===0) return 'FAIL: Khong co the san pham';var w=e[0].offsetWidth,ok=true;e.forEach(function(el){if(Math.abs(el.offsetWidth-w)>5)ok=false});return ok?'PASS':'FAIL: Cac the khong cung kich thuoc'})()")
println("KIEM TRA Cac the cung kich thuoc: " + kq8)
String kq9 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var nName = \"" + nName + "\";var nImg = \"" + nImg + "\";var nPrice = \"" + nPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'nName': nName,'nImg': nImg,'nPrice': nPrice,'kq5': kq5,'kq6': kq6,'kq7': kq7,'kq8': kq8 }; " + "(function(){var imgs=Array.from(window.document.querySelectorAll('" + cssCard + " img')).slice(0,4);if(!imgs||imgs.length===0) return 'FAIL: Khong tim thay anh';var ok=true;imgs.forEach(function(el){if(!el.src||(el.complete && el.naturalWidth===0))ok=false});return ok?'PASS':'FAIL: 4 anh dau tai khong thanh cong'})()")
println("KIEM TRA 4 anh dau tai thanh cong: " + kq9)
