import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-info, .product-item"
Thread.sleep(6000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var storedVars = { 'cssCard': cssCard }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("So the san pham hien thi ban dau n0=" + n0)
String r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var storedVars = { 'cssCard': cssCard,'n0': n0 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('B� nh� trong')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('256 GB')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem k�t qu�')")
Thread.sleep(4000);
String n1 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'n0': n0,'r': r }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("Sau thao tac n1=" + n1)
String kq17 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'n0': n0,'r': r,'n1': n1 }; " + "(Number(storedVars['n1'] || '" + n1 + "') > 0) ? 'PASS' : 'FAIL: Co ket qua sau khi loc bo nho'")
println("KIEM TRA Co ket qua sau khi loc bo nho: " + kq17)
String kq18 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'n0': n0,'r': r,'n1': n1,'kq17': kq17 }; " + "(storedVars['n1'] !== storedVars['n0']) ? 'PASS' : 'FAIL: So san pham thay doi sau khi loc bo nho'")
println("KIEM TRA So san pham thay doi sau khi loc bo nho: " + kq18)
