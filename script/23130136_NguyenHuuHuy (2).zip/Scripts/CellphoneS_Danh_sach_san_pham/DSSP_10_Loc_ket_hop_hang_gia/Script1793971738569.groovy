import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-info, .product-item"
String cssPrice = ".product__price--show, .product-price, .price"
String brand = "samsung"
String pMinK = "4000"
String pMaxK = "7000"
String pMin = "4000000"
String pMax = "7000000"
Thread.sleep(6000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("So the san pham hien thi ban dau n0=" + n0)
String r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('H�ng s�n xu�t')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Samsung')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem k�t qu�')")
Thread.sleep(4000);
String n1 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("Sau thao tac n1=" + n1)
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem theo gi�')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1 }; " + "(function(){var inputs=Array.from(window.document.querySelectorAll('input')).filter(function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)});if(inputs.length===0) return 'no_input';var set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;var vals=['" + pMinK + "','" + pMaxK + "'];inputs.forEach(function(el,idx){if(idx<2){el.focus();set.call(el,vals[idx]);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))}});return 'typed '+inputs.length+' inputs'})()")
println("O nhap gia: " + r)
Thread.sleep(800);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem k�t qu�')")
Thread.sleep(4000);
String n2 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1 }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("Sau thao tac n2=" + n2)
String nBrand = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1,'n2': n2 }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)&&(e.querySelector('h3, .product__name')||e).textContent.toLowerCase().indexOf('" + brand + "')!==-1}).length")
String badPrice = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var nBrand = \"" + nBrand + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1,'n2': n2,'nBrand': nBrand }; " + "(function(){var prices=Array.from(window.document.querySelectorAll('" + cssPrice + "')).filter(function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)});var pMin=parseInt(storedVars['pMin']||'" + pMin + "')||4000000;var pMax=parseInt(storedVars['pMax']||'" + pMax + "')||7000000;var bad=0;prices.forEach(function(e){var v=parseInt((e.textContent||'').replace(/\\D/g,''));if(v && (v < pMin || v > pMax)) bad++});return bad})()")
println("n2=" + n2 + " dung hang=" + nBrand + " gia sai=" + badPrice)
String kq23 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var nBrand = \"" + nBrand + "\";var badPrice = \"" + badPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1,'n2': n2,'nBrand': nBrand,'badPrice': badPrice }; " + "(Number(storedVars['n2'] || '" + n2 + "') > 0) ? 'PASS' : 'FAIL: Co ket qua'")
println("KIEM TRA Co ket qua: " + kq23)
String kq24 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var nBrand = \"" + nBrand + "\";var badPrice = \"" + badPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1,'n2': n2,'nBrand': nBrand,'badPrice': badPrice,'kq23': kq23 }; " + "(Number(storedVars['nBrand'] || '" + nBrand + "') === Number(storedVars['n2'] || '" + n2 + "')) ? 'PASS' : 'FAIL: Tat ca thuoc hang'")
println("KIEM TRA Tat ca thuoc hang: " + kq24)
String kq25 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var cssPrice = \"" + cssPrice + "\";var brand = \"" + brand + "\";var pMinK = \"" + pMinK + "\";var pMaxK = \"" + pMaxK + "\";var pMin = \"" + pMin + "\";var pMax = \"" + pMax + "\";var r = \"" + r + "\";var nBrand = \"" + nBrand + "\";var badPrice = \"" + badPrice + "\";var storedVars = { 'cssCard': cssCard,'cssPrice': cssPrice,'brand': brand,'pMinK': pMinK,'pMaxK': pMaxK,'pMin': pMin,'pMax': pMax,'n0': n0,'r': r,'n1': n1,'n2': n2,'nBrand': nBrand,'badPrice': badPrice,'kq23': kq23,'kq24': kq24 }; " + "(Number(storedVars['badPrice'] || '" + badPrice + "') === 0) ? 'PASS' : 'FAIL: Tat ca gia trong khoang'")
println("KIEM TRA Tat ca gia trong khoang: " + kq25)
