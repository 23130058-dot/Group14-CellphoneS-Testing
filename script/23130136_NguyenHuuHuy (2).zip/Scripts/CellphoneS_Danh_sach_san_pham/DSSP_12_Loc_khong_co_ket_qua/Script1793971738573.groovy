import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/mobile.html")
String cssCard = ".product-info-container, .product-info, .product-item"
String brand = "apple"
Thread.sleep(6000);
String n0 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var storedVars = { 'cssCard': cssCard,'brand': brand }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("So the san pham hien thi ban dau n0=" + n0)
String r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('H�ng s�n xu�t')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Apple')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem k�t qu�')")
Thread.sleep(4000);
String n1 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("Sau thao tac n1=" + n1)
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem theo gi�')")
Thread.sleep(1500);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1 }; " + "(function(){var inputs=Array.from(window.document.querySelectorAll('input')).filter(function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)});if(inputs.length===0) return 'no_input';var set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;var vals=['1000','2000'];inputs.forEach(function(el,idx){if(idx<2){el.focus();set.call(el,vals[idx]);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))}});return 'typed '+inputs.length+' inputs'})()")
println("O nhap gia: " + r)
Thread.sleep(800);
r = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1 }; " + "(function(txt){var els=Array.from(window.document.querySelectorAll('button, div, span, a, label, p'));for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').trim();if((t===txt||t.includes(txt))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)){e.click();e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'clicked'}}return 'not_found'})('Xem k�t qu�')")
Thread.sleep(4000);
String n2 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1 }; " + "Array.prototype.filter.call(window.document.querySelectorAll('" + cssCard + "'),function(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}).length")
println("Sau thao tac n2=" + n2)
String kq27 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1,'n2': n2 }; " + "(Number(storedVars['n2'] || '" + n2 + "') === 0) ? 'PASS' : 'FAIL: Khong co the san pham'")
println("KIEM TRA Khong co the san pham: " + kq27)
String kq28 = selenium.getEval(" var cssCard = \"" + cssCard + "\";var brand = \"" + brand + "\";var r = \"" + r + "\";var storedVars = { 'cssCard': cssCard,'brand': brand,'n0': n0,'r': r,'n1': n1,'n2': n2,'kq27': kq27 }; " + "(/kh�ng t�m th�y|kh�ng c� s�n ph�m|ch�a c� s�n ph�m|kh�ng c� k�t qu�/i.test(window.document.body.innerText)) ? 'PASS' : 'FAIL: Hien thong bao khong co ket qua'")
println("KIEM TRA Hien thong bao khong co ket qua: " + kq28)
