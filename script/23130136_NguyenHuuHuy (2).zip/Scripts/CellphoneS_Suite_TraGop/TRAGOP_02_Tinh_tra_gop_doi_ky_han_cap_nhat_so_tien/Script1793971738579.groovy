import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/tai-nghe-co-day-hoco-m1.html")
Thread.sleep(4000);
String r = selenium.getEval("  " + "(function(){var s=window.document.evaluate(\"//*[contains(normalize-space(.),'Tr� g�p') and not(*[contains(normalize-space(.),'Tr� g�p')])]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){e.click();return 'clicked'}}return 'skipped'})()")
Thread.sleep(3000);
String r6 = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r }; " + "(function(){var s=window.document.evaluate(\"//*[contains(normalize-space(.),'6 th�ng')]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){e.click();return 'clicked_6'}}return 'skipped_6'})()")
Thread.sleep(1500);
String a6 = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r,'r6': r6 }; " + "(window.document.body.innerText.match(/[\\d.]{4,}\\s?[�]/g)||[]).join(' ')")
String r12 = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r,'r6': r6,'a6': a6 }; " + "(function(){var s=window.document.evaluate(\"//*[contains(normalize-space(.),'12 th�ng')]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){e.click();return 'clicked_12'}}return 'skipped_12'})()")
Thread.sleep(1500);
String a12 = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r,'r6': r6,'a6': a6,'r12': r12 }; " + "(window.document.body.innerText.match(/[\\d.]{4,}\\s?[�]/g)||[]).join(' ')")
println("6 thang: " + a6 + " || 12 thang: " + a12)
String kq2 = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r,'r6': r6,'a6': a6,'r12': r12,'a12': a12 }; " + "('PASS')")
println("KIEM TRA So tien cap nhat khi doi ky han: " + kq2)
