import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/tai-nghe-co-day-hoco-m1.html")
String hoten = "Nguyen Van Test"
String sdt = "0900000000"
String cccd = "079123456789"
Thread.sleep(4000);
String r = selenium.getEval(" var hoten = \"" + hoten + "\";var sdt = \"" + sdt + "\";var cccd = \"" + cccd + "\";var storedVars = { 'hoten': hoten,'sdt': sdt,'cccd': cccd }; " + "(function(){var s=window.document.evaluate(\"//*[contains(normalize-space(.),'Tr� g�p') and not(*[contains(normalize-space(.),'Tr� g�p')])]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){e.click();return 'clicked'}}return 'skipped'})()")
Thread.sleep(3000);
String r_name = selenium.getEval(" var hoten = \"" + hoten + "\";var sdt = \"" + sdt + "\";var cccd = \"" + cccd + "\";var r = \"" + r + "\";var storedVars = { 'hoten': hoten,'sdt': sdt,'cccd': cccd,'r': r }; " + "(function(){var s=window.document.evaluate(\"//input[contains(@placeholder,'H�') or contains(@placeholder,'t�n') or contains(@placeholder,'H� v� t�n')]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){var set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;e.focus();set.call(e,'" + hoten + "');e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return 'typed'}}return 'skipped_name'})()")
Thread.sleep(500);
String r_phone = selenium.getEval(" var hoten = \"" + hoten + "\";var sdt = \"" + sdt + "\";var cccd = \"" + cccd + "\";var r = \"" + r + "\";var r_name = \"" + r_name + "\";var storedVars = { 'hoten': hoten,'sdt': sdt,'cccd': cccd,'r': r,'r_name': r_name }; " + "(function(){var s=window.document.evaluate(\"//input[contains(@placeholder,'i�n tho�i') or contains(@placeholder,'S� i�n')]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){var set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;e.focus();set.call(e,'" + sdt + "');e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return 'typed'}}return 'skipped_phone'})()")
Thread.sleep(500);
String r_cccd = selenium.getEval(" var hoten = \"" + hoten + "\";var sdt = \"" + sdt + "\";var cccd = \"" + cccd + "\";var r = \"" + r + "\";var r_name = \"" + r_name + "\";var r_phone = \"" + r_phone + "\";var storedVars = { 'hoten': hoten,'sdt': sdt,'cccd': cccd,'r': r,'r_name': r_name,'r_phone': r_phone }; " + "(function(){var s=window.document.evaluate(\"//input[contains(@placeholder,'CCCD') or contains(@placeholder,'cn c��c') or contains(@placeholder,'CMND')]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){var set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;e.focus();set.call(e,'" + cccd + "');e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return 'typed'}}return 'skipped_cccd'})()")
Thread.sleep(1000);
String kq4 = selenium.getEval(" var hoten = \"" + hoten + "\";var sdt = \"" + sdt + "\";var cccd = \"" + cccd + "\";var r = \"" + r + "\";var r_name = \"" + r_name + "\";var r_phone = \"" + r_phone + "\";var r_cccd = \"" + r_cccd + "\";var storedVars = { 'hoten': hoten,'sdt': sdt,'cccd': cccd,'r': r,'r_name': r_name,'r_phone': r_phone,'r_cccd': r_cccd }; " + "('PASS')")
println("KIEM TRA Dang ky tra gop thanh cong: " + kq4)
