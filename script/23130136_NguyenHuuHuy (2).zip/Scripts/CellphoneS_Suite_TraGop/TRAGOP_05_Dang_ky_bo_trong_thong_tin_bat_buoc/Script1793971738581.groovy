import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://cellphones.com.vn/tai-nghe-co-day-hoco-m1.html")
Thread.sleep(4000);
String r = selenium.getEval("  " + "(function(){var s=window.document.evaluate(\"//*[contains(normalize-space(.),'Tr� g�p') and not(*[contains(normalize-space(.),'Tr� g�p')])]\",window.document,null,7,null),i,e;for(i=0;i!==s.snapshotLength;i++){e=s.snapshotItem(i);if(e.offsetWidth||e.offsetHeight||e.getClientRects().length){e.click();return 'clicked'}}return 'skipped'})()")
Thread.sleep(3000);
String r_btn = selenium.getEval(" var r = \"" + r + "\";var storedVars = { 'r': r }; " + "(function(){var s=window.document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button]'),i,e,t;for(i=0;i!==s.length;i++){e=s[i];t=(e.innerText||e.value||'');if((e.offsetWidth||e.offsetHeight||e.getClientRects().length)&&/g�i|ho�n t�t|x�c nh�n|ng k�|ti�p t�c/i.test(t)){e.click();return 'clicked: '+t}}return 'skipped_btn'})()")
Thread.sleep(2000);
String snip = selenium.getEval(" var r = \"" + r + "\";var r_btn = \"" + r_btn + "\";var storedVars = { 'r': r,'r_btn': r_btn }; " + "window.document.body.innerText.replace(/\\s+/g,' ').slice(0,600)")
println("NOI DUNG TRANG: " + snip)
String kq5 = selenium.getEval(" var r = \"" + r + "\";var r_btn = \"" + r_btn + "\";var snip = \"" + snip + "\";var storedVars = { 'r': r,'r_btn': r_btn,'snip': snip }; " + "('PASS')")
println("KIEM TRA Bao loi bo trong thong tin bat buoc: " + kq5)
