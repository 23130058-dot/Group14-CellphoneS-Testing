<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CellphoneS_Danh_sach_san_pham</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>432e9f9d-35ba-40e1-836f-e51947838807</testSuiteGuid>
   <testCaseLink>
      <guid>11243e2d-0a16-4867-a982-99ba012bce59</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_00_Kiem_tra_moi_truong</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>92bd680d-85f4-4d77-8029-678836f1372d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_00b_Kham_pha_bo_loc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6cbdfb1d-1506-454b-b94e-9c93aea8545d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_01_Hien_thi_the_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1a7790f0-a19a-42f1-ba2c-215be4ac116f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_02_GUI_bo_cuc_the_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>feef44b6-8732-4c51-bd5b-f2c78ffb46d7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_03_Xem_them_tai_them_san_pham</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1bad6a5f-ed9f-4de9-945e-90e5828776d6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_04_Loc_don_theo_hang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dbba913c-7c0d-41c0-b310-1b58cc74a2d0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_05_Loc_don_theo_khoang_gia</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>be12c4df-482c-4c1e-ae26-3e0a6b74f6ae</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_06_Loc_don_theo_RAM</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1a61b1ff-f108-46aa-941e-5647fc1b5c40</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_07_Loc_don_theo_bo_nho</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>0cc962dd-ec4e-445d-98fc-4a9316f2e42a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_08_Loc_don_theo_man_hinh</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a181b86f-aca6-4d0a-ba5f-671216ffe57d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_09_Loc_don_theo_trang_thai_con_hang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1d4e8948-9b31-4035-ac38-cefeec0ba95d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_10_Loc_ket_hop_hang_gia</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7f591ee2-572c-47ca-94ff-6b68c9506078</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_11_Bo_chon_bo_loc_ve_ban_dau</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a95f82ad-bc48-49b5-a6d0-09bd21ee837c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_12_Loc_khong_co_ket_qua</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>30901bb4-bbdb-4b99-9894-b9e9a7fcc6ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_13_Sap_xep_gia_thap_den_cao</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c3212de3-9d95-4462-bea0-906dfeadd005</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_14_Sap_xep_gia_cao_den_thap</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7c301dc1-a154-48a6-9f0e-6b718a25add3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_15_Sap_xep_pho_bien_ban_chay</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1c82423d-6551-40fb-9bc2-c486e0750b25</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_16_Sap_xep_khuyen_mai_HOT</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c2396f2f-fdc9-4ef4-bd0a-36fbdf8511b5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Danh_sach_san_pham/DSSP_17_Giu_bo_loc_khi_doi_cach_sap_xep</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    