<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CellphoneS_Suite_TraGop</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ee8f3c99-0229-41f3-a5c8-5c94e95e05b5</testSuiteGuid>
   <testCaseLink>
      <guid>07535b05-a239-4804-8c88-8793f59d413f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_00_Kham_pha_trang_tra_gop</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ba6ebc62-59e0-401d-b9d2-43b33bd69823</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_01_Tinh_tra_gop_chon_tra_truoc_va_ky_han</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>adcee0b2-4d9d-4f59-8c37-a908be94c17c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_02_Tinh_tra_gop_doi_ky_han_cap_nhat_so_tien</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>b09df1df-adcf-4ef1-adf8-df1094ed1818</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_03_Tinh_tra_gop_tra_truoc_vuot_gia_bao_loi</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>509db93f-b93b-4a9e-84a5-0763646ae557</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_04_Dang_ky_tra_gop_thanh_cong</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>25d60cce-7d80-45a6-b0f2-bdb00f7888ed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_05_Dang_ky_bo_trong_thong_tin_bat_buoc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e2d878b8-15ce-4e50-90f2-9aed7e0641bf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_06_Tai_file_sai_dinh_dang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4343e5a3-2bd5-43db-9b88-de1f97edeccf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_07_Tai_file_qua_dung_luong</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>59b79ff4-c716-47a0-bf7a-dc3590360b4c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_08_Nhap_CCCD_sai_dinh_dang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>84930af7-d482-42c7-864e-754651d57648</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_09_Chuong_trinh_sinh_vien_hien_thi_dieu_kien</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c481195d-2672-41f3-b392-eff6b002fa26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_10_Kiem_tra_nhap_so_dien_thoai_khong_hop_le</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e4f4fbf3-faca-4439-889a-4aa67280a821</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_11_Kiem_tra_chon_cong_ty_tai_chinh</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>df8d2c36-056e-4442-8c6e-a27c7988f065</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_12_Kiem_tra_qua_the_tin_dung_ngan_hang</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>78fbb531-9fba-4fa6-964c-703c6c0acb8c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_TraGop/TRAGOP_13_Kiem_tra_dong_modal_dang_ky_tra_gop</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    