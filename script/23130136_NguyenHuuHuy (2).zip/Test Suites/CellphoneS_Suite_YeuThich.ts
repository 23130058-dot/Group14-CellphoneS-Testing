<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CellphoneS_Suite_YeuThich</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>644c962c-d202-4ba5-87a1-384e4b58dd5f</testSuiteGuid>
   <testCaseLink>
      <guid>ed633524-ecbd-4e7d-80b3-d1d68ed1bb97</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_00_Kham_pha_nut_yeu_thich_tren_trang_chi_tiet</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dbcdff0f-7b2f-4271-9c09-fcbae8c59934</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_01_Them_san_pham_vao_danh_sach_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6f079c5a-32a2-41ff-9c1c-fa43fd73fdea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_02_Bong_xoa_san_pham_khoi_yeu_thich_toggle</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>b618e6e4-a2d2-4d2b-a5ee-9407875e97bd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_03_Mo_danh_sach_yeu_thich_tu_header</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dfb8b71a-7e64-40e8-a7f7-48a5dc548786</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_04_Kiem_tra_hien_thi_san_pham_trong_danh_sach_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6e1c42ca-7daa-4986-bcc7-7e994c14e324</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_05_Xoa_san_pham_truc_tiep_trong_trang_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e6d587b2-989e-446e-9f62-775913c2acc0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_06_Kiem_tra_trang_yeu_thich_trong</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a46cc24e-6523-40d6-b2ff-f4158121266c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_07_Them_nhieu_san_pham_vao_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>b821cd03-4a7f-4d0b-99ea-b5321c5f6826</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_08_Chuyen_den_trang_chi_tiet_tu_danh_sach_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>92862420-1bfb-4ad0-b320-282e45bdfb3a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_09_Them_nhanh_yeu_thich_tu_trang_danh_muc</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>5f6a2fa8-51e5-43ec-8c9b-4ba5953d701f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_10_Them_vao_gio_hang_tu_danh_sach_yeu_thich</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6cee3c39-f643-4969-903a-a50210a2f684</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_11_Kiem_tra_dong_bo_yeu_thich_sau_khi_refresh</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>75418708-0562-459b-965a-057ef5d69434</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_12_Kiem_tra_so_luong_dem_yeu_thich_tren_header</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>96931ccb-d6a0-4d48-9a3d-bbb2da143ba2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CellphoneS_Suite_YeuThich/YEUTHICH_13_Xoa_tat_ca_san_pham_yeu_thich_cung_luc</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    